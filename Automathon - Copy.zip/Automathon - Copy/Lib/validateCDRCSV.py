import csv	


def returnCDRROW(file,directionOfCall,IQSIMNumber):
	ifile = open(file,"rb")
	reader = csv.reader(ifile)
	rownum = 0
	ver = ""
	for row in reader:
		if rownum == 0:
			header = row
		else:
			column = 5
						
			for col in row:
				
				if row[column] == IQSIMNumber and row[2] == directionOfCall:
					
					ver = "Break"
					return row
					break
		if ver == "Break":
			break
		rownum += 1
	ifile.close()
	

