import csv	


def getLocatorType(file,elementName):
	ifile = open(file,"rb")
	reader = csv.reader(ifile)
	rownum = 0
	for row in reader:
		if rownum == 0:
			header = row
		else:
			column = 0
			for col in row:
				if row[column] == elementName:
					locType = row[column+1]
					return locType			
					break
		rownum += 1
	ifile.close()


def getLocatorValue(file,elementName):
	ifile = open(file,"rb")
	reader = csv.reader(ifile)
	rownum = 0
	for row in reader:
		if rownum == 0:
			header = row
		else:
			column = 0
			for col in row:
				if row[column] == elementName:
					locValue = row[column+2]
					return locValue			
					break
		rownum += 1
	ifile.close()				
	
def getRestParams(file,featureID,param):
	ifile = open(file,"rb")
	reader = csv.reader(ifile)
	rownum = 0
	for row in reader:
		if rownum == 0:
			header = row
		else:
			column = 0
			for col in row:
				if row[column] == featureID:
					if row[column+1] == param:
						restrow = row
						return restrow			
						break
		rownum += 1
	ifile.close()		
	
def getRESTResponseValue(response, value1, value2):
	print response
	print value1
	print value2