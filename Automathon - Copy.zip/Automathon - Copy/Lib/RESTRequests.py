import requests
import json
import boto3

def requestPost(url,payload,header=None):
	r = requests.post(url, data=json.dumps(payload) , headers=header)
	if r.status_code == 200:
		t = json.loads(r.content)
		return t
	else:
		raise ValueError('Post method did not complete successfully.')

def requestPut(url,payload,header=None):	
	r = requests.put(url, data=json.dumps(payload) , headers=header)
	if r.status_code == 200:
		t = json.loads(r.content)
		return t
	else:
		raise ValueError('Post method did not complete successfully.')
	
	
def getCognitoToken(clientID,userName,passWord):
	client = boto3.client('cognito-idp')
	response = client.initiate_auth(
		AuthFlow='USER_PASSWORD_AUTH',
		ClientId=clientID,
		AuthParameters={
			"USERNAME": userName,
			"PASSWORD": passWord
		}
	)
	return response
	
	
