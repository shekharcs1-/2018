import requests
import json
import boto3

def requestPost(url,payload,header=None):
	r = requests.post(url, data=json.dumps(payload) , headers=header)
	print r
	t = json.loads(r.content)
	print t
	#t1= json.loads(r.headers)
	#print t1
	print r.status_code
	


def getCognitoToken(clientID,userName,passWord):
	client = boto3.client('cognito-idp')
	response = client.initiate_auth(
		AuthFlow='USER_PASSWORD_AUTH',
		ClientId=clientID,
		AuthParameters={
			"USERNAME": userName,
			"PASSWORD": passWord
		}
	)
	print response
'''
url = 'https://8ywb3y8eah.execute-api.eu-west-2.amazonaws.com/dev/destination-numbers'
payload = {u'operation': u'add', u'phoneNumber': '+919158408120', u'description': 'rest api testing'}
header = {'Content-Type': 'application/json', 'Authorization': 'eyJraWQiOiI5dVBHVXRzcGRFUEpKT1ZtdjRiSDUyRm9vZWs0YjkwYlZoYW02ekp2QkRVPSIsImFsZyI6IlJTMjU2In0.eyJjdXN0b206b3JnYW5pemF0aW9uIjoiQXZpdmEiLCJzdWIiOiI3NzgwYjJmMi02OTEwLTRmZTQtODgzNy0yNWQ3OTdlMjc2YTEiLCJlbWFpbF92ZXJpZmllZCI6ZmFsc2UsImlzcyI6Imh0dHBzOlwvXC9jb2duaXRvLWlkcC5ldS13ZXN0LTIuYW1hem9uYXdzLmNvbVwvZXUtd2VzdC0yX1I5clJzTlpSQiIsImNvZ25pdG86dXNlcm5hbWUiOiJQYXZhbiIsImN1c3RvbTpwZXJtaXNzaW9uIjoie1wiVXNlclwiOltcIkFcIixcIkVcIixcIlZcIixcIkNcIixcIkRcIl0sXCJSb2xlXCI6W1wiQVwiLFwiRVwiLFwiVlwiLFwiRFwiXSxcIkJ1eSBOdW1iZXJcIjpbXCJWXCIsXCJBXCJdLFwiSW5ib3VuZCBOdW1iZXJzXCI6W1wiVlwiLFwiRVwiXSxcIkNhbGwgTG9nc1wiOltcIlZcIl0sXCJEZXN0aW5hdGlvbiBOdW1iZXJcIjpbXCJWXCIsXCJBXCIsXCJFXCIsXCJEXCJdLFwiQ29zdCBDZW50ZXJcIjpbXCJBXCIsXCJFXCIsXCJEXCIsXCJWXCJdLFwiQ2FsbCBTdHVkaW9cIjpbXCJWXCIsXCJBXCIsXCJFXCIsXCJEXCJdfSIsImdpdmVuX25hbWUiOiJDdXN0b21lciBBZG1pbmlzdHJhdG9yIiwiYXVkIjoiMmcxZWRrNGNrMnJudmt2bWxqb3JiaGszMXAiLCJldmVudF9pZCI6IjA1ODg4OTRiLWE0NDYtMTFlOC05YjRmLTI1ZjI3ZjA4MmI0ZCIsInRva2VuX3VzZSI6ImlkIiwiYXV0aF90aW1lIjoxNTM0NzQ4MTI4LCJuYW1lIjoiTkEiLCJleHAiOjE1MzQ3NTE3MjgsImN1c3RvbTpyb2xlIjoiQWRtaW5pc3RyYXRvciIsImlhdCI6MTUzNDc0ODEyOCwiZmFtaWx5X25hbWUiOiIxMjM0NTY3ODg5OSIsImVtYWlsIjoicGF2YW5rdW1hci5tYXJ0aGFsYUB2b2RhZm9uZS5jb20ifQ.Juiz9YHuVj6P54AYr5ngGpF0Vtk08LZ5dkpGzFxopWs75-F7LVnBeAk9wAW5Yq5MLNbT-WQeWu5B0_MrKvnPpzBHOElnAo5-tRYf5USsKDlXmkvDIRd4McG-889_uANZDYKJZpfQZc7eow5MUnJP-ZjMdfn2UYdcJnW5Foh5zMuzlX7JjW7g-KIQ7eU2_G48nG6jDyV8Pdnmr2BX9bBtnq-TzLeUNNlhhyXbGFu-xVTIz7Pp_nFD5CE1k1Mccq8rtqunMaJoAW3MU4uEhS47uS-fTGn7QbRDzJhKWFHaHol8p-3zX-BAsNYbrG9DWrh0Dmu6ePvKgtzuFTwRfkTXXw'}	

requestPost(url,payload,header)

'''
	
clientID = '2g1edk4ck2rnvkvmljorbhk31p'
userName = 'Priya'
passWord = 'Priya@123'

getCognitoToken(clientID,userName,passWord)

