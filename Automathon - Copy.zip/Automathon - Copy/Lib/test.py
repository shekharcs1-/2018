import requests
import json
import urllib
url = 'https://yykar1u2d4.execute-api.eu-west-2.amazonaws.com/Dev/ain/users'
payload = {"item": { "emailUserName": "customer@vodafone.com" ,  "password": "5a22c24af84220ef9ef0d4bdfacf2a5e" , "operation": "login" } } 
r = requests.post(url, data=json.dumps(payload))
print(r.content)
t = json.loads(r.content)
print('test')
print(t)

