import boto3
import botocore


def downloadCSVFile(Key):
	BUCKET_NAME = 'ivlambdalogs' # replace with your bucket name
	KEY = Key # replace with your object key

	s3 = boto3.resource('s3')

	try:
		s3.Bucket(BUCKET_NAME).download_file(KEY, 'C:\Automation\AdvancedIN\CDR\localCopy.csv')
	except botocore.exceptions.ClientError as e:
		if e.response['Error']['Code'] == "404":
			print("The object does not exist.")
		else:
			raise