import csv	


def getLocatorType(file,elementName):
	ifile = open(file,"rb")
	reader = csv.reader(ifile,delimiter="|")
	rownum = 0
	for row in reader:
		if rownum == 0:
			header = row
		else:
			column = 0
			for col in row:
				if row[column] == elementName:
					locType = row[column+1]
					return locType			
					break
		rownum += 1
	ifile.close()


def getLocatorValue(file,elementName):
	ifile = open(file,"rb")
	reader = csv.reader(ifile,delimiter="|")
	rownum = 0
	for row in reader:
		if rownum == 0:
			header = row
		else:
			column = 0
			for col in row:
				if row[column] == elementName:
					locValue = row[column+2]
					return locValue			
					break
		rownum += 1
	ifile.close()				
	
def getRestParams(file,param):
	ifile = open(file,"rb")
	reader = csv.reader(ifile)
	rownum = 0
	for row in reader:
		if rownum == 0:
			header = row
		else:
			column = 0
			for col in row:
				if row[column] == param:
					restrow = row
					return restrow			
					break
		rownum += 1
	ifile.close()		
	
def getTestData(file,param):
	ifile = open(file,"rb")
	reader = csv.reader(ifile,delimiter="|")
	rownum = 0
	for row in reader:
		if rownum == 0:
			header = row
		else:
			column = 0
			for col in row:
				if row[column] == param:
					value = row[column+1]
					return value			
					break
		rownum += 1
	ifile.close()

	
def getNumberOfRowsInCSV(file):
	ifile = open(file,"rb")
	reader = csv.reader(ifile)
	numOfRows = len(list(reader))
	return numOfRows-1
	
