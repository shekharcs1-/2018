###################################################################################################
# Description : ScriptExecuter modules helps in executing test case\suite.
# Developer   : Anherudh Kamath
# Date        : 14-Jan,2016
# Updated     : 28 August 2018
# Changes     : Implemented the script to pick up the build number and jobname at run time to create the folder
###################################################################################################


import sys
import os

import xml.etree.ElementTree as ET
from xml.etree.ElementTree import ParseError
from robot import run
from time import strftime

scriptPath = os.path.abspath(os.path.join(os.path.dirname( __file__ ), '..', 'scripts'))
parserFileName = os.path.abspath(os.path.join(os.path.dirname( __file__ ), '..', 'config','runDetails.xml'))

def createReportFolder(reportFolderName):
    tStamp = strftime("%d_%m_%Y")
#    reportFolder = os.path.abspath(os.path.join(os.path.dirname( __file__ ), '..', 'output',reportFolderName+'_'+ tStamp))
    reportFolder = os.path.abspath(os.path.join(os.path.dirname( __file__ ), '..', 'output',reportFolderName))
    return reportFolder

def ScriptExecuter1 (buildID):
    try:
        tree = ET.parse(parserFileName)
        root = tree.getroot()
        testSuiteDet = []
        tagDet = []

        for exeDet in root.getchildren():
            testSuitePath = os.path.join(scriptPath,exeDet.attrib['name'])
            testSuiteName = exeDet.attrib['name'].split(".")[0]
            run(testSuitePath, outputdir=createReportFolder(buildID), reportbackground='white:white:white')

    except ParseError:
        sys.exit("Check the runDetails XML file.. Pattern not well-formed")

    except:
        print "Error : "
        print sys.exc_info()[0]
        print buildID
ScriptExecuter1 (sys.argv[1])